package com.maneef.doctorhouse1.model



data class MedicalForm(val id:Int,val name: String,val age:String,val phone:String,val gender:String,val medicalHistory:String,val medicineAllergic:String,val additionalInfo: String,val area: String,val neighbourhood:String,val closetPlace:String,val lat: String,val lang: String,val orderTypesAsked: ArrayList<String>,val readied: Int,val type:Int) {

    constructor():this(0,"","","","","","","","","","","","", arrayListOf(""),-1,-1)
    constructor(name: String,age:String,phone: String,gender: String,medicalHistory: String,medicineAllergic: String,additionalInfo: String,area: String,neighbourhood: String,closetPlace: String,lat: String,lang: String,orderTypesAsked: ArrayList<String>,readied: Int,type: Int):this(0,name, age, phone, gender, medicalHistory, medicineAllergic, additionalInfo, area, neighbourhood, closetPlace,lat,lang,orderTypesAsked,readied,type)

}