package com.maneef.doctorhouse1.service

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.base.App.Companion.CHANNEL_ID
import com.maneef.doctorhouse1.base.App.Companion.NOTIFICATION_ID
import com.maneef.doctorhouse1.db.AppDBHelper
import com.maneef.doctorhouse1.model.MedicalForm
import com.maneef.doctorhouse1.ui.home.admin.AdminMainActivity

class NotificationCenter : Service() {

    private lateinit var database: DatabaseReference
    private lateinit var pendingIntent: PendingIntent
    private lateinit var notification: NotificationCompat.Builder
    private lateinit var sqlDB: AppDBHelper

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }

    override fun onCreate() {
        super.onCreate()
        database = Firebase.database.reference
        sqlDB = AppDBHelper(this)
        Log.w(AppConstants.TAG, "Service Created")
    }


    override fun onDestroy() {
        super.onDestroy()
        val restartService = Intent("RestartService")
        sendBroadcast(restartService)
        Log.w(AppConstants.TAG, "Service Destroy")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {


        // Create an explicit intent for an Activity in your app

        val i = Intent(this, AdminMainActivity::class.java)
        pendingIntent = PendingIntent.getActivity(this, 0, i, 0)


        val notificationCompat = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("خدمة تلقي الإشعارات تعمل حالياً")
            .setSmallIcon(R.drawable.ic_heart_test)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setSound(Uri.parse("android.resource://${baseContext.packageName}/R.raw.notification_effect.mp3"))
            .build()

        startForeground(2022, notificationCompat)

        dataChanged()
        return START_STICKY

    }


    private fun dataChanged() {
        database.child(AppConstants.MEDICAL_FORM).addValueEventListener(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.value != null) {
                    for (ds in snapshot.children) {
                        val medicalForm = ds.getValue(MedicalForm::class.java)
                        Log.e(AppConstants.TAG, "Readied (Notification) :${medicalForm}")
                        if (medicalForm!!.readied != 1) {
                            with(NotificationManagerCompat.from(baseContext)) {
                                //sqlDB.addOrder()
                                // notificationId is a unique int for each notification that you must define
                                notification = NotificationCompat.Builder(this@NotificationCenter, CHANNEL_ID)
                                    .setSmallIcon(R.drawable.ic_heart_test)
                                    .setContentTitle("تم تلقي طب جديد")
                                    .setContentText("قام ${medicalForm.name} بطلب خدمة جديدة ")
                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                    // Set the intent that will fire when the user taps the notification
                                    .setContentIntent(pendingIntent)
                                    .setAutoCancel(true)
                                    .setSound(Uri.parse("android.resource://${baseContext.packageName}/R.raw.notification_effect.mp3"))

                                notify(NOTIFICATION_ID, notification.build())
                                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                                } else {
                                    //deprecated in API 26
                                    v.vibrate(500)
                                }
                            }
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })

    }

}