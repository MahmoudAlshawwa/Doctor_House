package com.maneef.doctorhouse1.ui.orderDetails

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.github.ybq.android.spinkit.sprite.Sprite
import com.github.ybq.android.spinkit.style.CubeGrid
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.model.LabTestForm

class DetailsLaboratoryTestingFragment : Fragment() {
    private lateinit var root: View
    private lateinit var database: DatabaseReference
    private lateinit var patientNameDetails: TextView
    private lateinit var patientAgeDetails: TextView
    private lateinit var patientPhoneDetails: TextView
    private lateinit var patientGenderDetails: TextView
    private lateinit var addressDetails: TextView
    private lateinit var btnGoToMapDetails: TextView
    private lateinit var btnSubmitFormDetails: TextView
    private lateinit var btnCancelRequestDetails: TextView
    private lateinit var bottomSheet : ConstraintLayout
    private lateinit var contentMain : ConstraintLayout
    private lateinit var sheetBehavior: BottomSheetBehavior<*>
    private lateinit var detailsGroup: TextView
    private lateinit var child: String
    private lateinit var pLat: String
    private lateinit var pLang: String
    private lateinit var progressBar: ProgressBar
    private lateinit var labSheetImg: ImageView
    private lateinit var test: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        root = inflater.inflate(R.layout.fragment_details_laboratory_testing,container,false)
        contentMain =  root.findViewById(R.id.content_main)
        bottomSheet = root.findViewById(R.id.bottom_sheet)
        sheetBehavior = BottomSheetBehavior.from(bottomSheet)
        detailsGroup = root.findViewById(R.id.tv_show_sheet)
        database = Firebase.database.reference
        child = requireArguments().getString("child")!!
        getSingleChild(child)
        patientNameDetails = root.findViewById(R.id.tv_lab_details_patient_name)
        patientAgeDetails = root.findViewById(R.id.tv_lab_details_patient_age)
        patientPhoneDetails = root.findViewById(R.id.tv_lab_details_phone_number)
        patientGenderDetails = root.findViewById(R.id.tv_lab_details_gender)
        addressDetails = root.findViewById(R.id.tv_lab_details_address)
        btnSubmitFormDetails = root.findViewById(R.id.tv_lab_accept_request)
        btnGoToMapDetails = root.findViewById(R.id.tv_lab_details_go_to_map)
        labSheetImg = root.findViewById(R.id.iv_lab_sheet)
        progressBar = root.findViewById(R.id.pb_details_lab)
        val cubeGrid: Sprite = CubeGrid()
        progressBar.indeterminateDrawable = cubeGrid
        test = root.findViewById(R.id.tv_test1)
        return root
    }

    override fun onResume() {
        super.onResume()
        detailsGroup.setOnClickListener {
            if (sheetBehavior.state != BottomSheetBehavior.STATE_EXPANDED) {
                sheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
                Log.e("Rabee", "Expand sheet")
            } else {
                sheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
                Log.e("Rabee", "Close sheet")
            }
        }

        btnGoToMapDetails.setOnClickListener {
            showProgressBar()
            Dexter.withContext(requireContext())
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(object : PermissionListener {
                    override fun onPermissionGranted(response: PermissionGrantedResponse) {
                        val manager =
                            requireActivity().getSystemService(Context.LOCATION_SERVICE) as LocationManager
                        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            hideProgressBar()
                            checkGPSEnable()
                        } else {
                            hideProgressBar()
                            val bndl = Bundle()
                            bndl.putDouble("pLat",pLat.toDouble())
                            bndl.putDouble("pLang",pLang.toDouble())
                            findNavController().navigate(R.id.action_detailsLaboratoryTestingFragment_to_mapsFragment,bndl)
                        }
                    }

                    override fun onPermissionRationaleShouldBeShown(
                        p0: PermissionRequest?,
                        p1: PermissionToken?
                    ) {
                        hideProgressBar()
                        p1!!.continuePermissionRequest()
                    }

                    override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                        hideProgressBar()
                    }
                }).check()
        }

        btnSubmitFormDetails.setOnClickListener {
            updateFormStatus(child)
        }
    }

    private fun getSingleChild(child: String) {
        database.child(AppConstants.MEDICAL_LAB_TESTS).child(child)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val labMedicalForm = snapshot.getValue(LabTestForm::class.java)
                    if (labMedicalForm != null) {
                        if(labMedicalForm.testSheet != "")
                            Glide.with(requireContext()).load(labMedicalForm.testSheet).into(labSheetImg)
                        patientNameDetails.text = ("الإسم:  ${labMedicalForm.name}")
                        patientAgeDetails.text = ("العمر:  ${labMedicalForm.age}")
                        patientPhoneDetails.text = ("رقم الجوال: ${labMedicalForm.phone}")
                        patientGenderDetails.text = (labMedicalForm.gender)
                        val address = "${labMedicalForm.area} ${labMedicalForm.neighbourhood} ${labMedicalForm.closetPlace}"
                        addressDetails.text = address
                        pLat = labMedicalForm.lat
                        pLang = labMedicalForm.lang
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.d("Error", "medicalForm ${error.toException()}")
                }
            })
    }

    private fun updateFormStatus(child: String) {
        database.child(AppConstants.MEDICAL_LAB_TESTS).child(child).child("readied").setValue(1)
            .addOnSuccessListener {
                findNavController().navigate(R.id.action_detailsLaboratoryTestingFragment_to_adminHomeFragment)
            }.addOnFailureListener {
                Toast.makeText(requireContext(),"", Toast.LENGTH_LONG).show()
            }
    }

    private fun checkGPSEnable() {
        val dialogBuilder = AlertDialog.Builder(requireContext())
        dialogBuilder.setMessage(R.string.gps_check)
            .setCancelable(false)
            .setPositiveButton(R.string.yes) { _, _ ->
                startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }
            .setNegativeButton(R.string.no) { dialog, _ ->
                dialog.cancel()
            }
        val alert = dialogBuilder.create()
        alert.setOnShowListener {
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.colorPrimaryDark))
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(android.R.color.holo_red_dark))
        }
        alert.show()
    }

    private fun showProgressBar() {
        progressBar.visibility = ProgressBar.VISIBLE
    }

    private fun hideProgressBar() {
        progressBar.visibility = ProgressBar.GONE
    }

}