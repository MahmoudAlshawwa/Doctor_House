package com.maneef.doctorhouse1.base

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.ui.auth.AuthActivity

class SplashScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        window.decorView.apply {
            systemUiVisibility =
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        }
    }
    override fun onResume() {
        super.onResume()
        Handler(Looper.getMainLooper()).postDelayed({
        val i = Intent(this@SplashScreenActivity, AuthActivity::class.java)
        startActivity(i)
        finish()
        }, 2500)
    }
}