package com.maneef.doctorhouse1.model

import android.os.Parcel
import android.os.Parcelable

data class Order(val name: String?,val phone: String?,val address: String?,val readied: Int,val type: Int) : Parcelable {
    constructor():this("","","",-1,-1)

    constructor(parcel: Parcel) : this(
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readInt(),
            parcel.readInt()

    )

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest!!.writeString(name)
        dest.writeString(address)
        dest.writeString(phone)
        dest.writeInt(readied)
        dest.writeInt(type)

    }

    companion object CREATOR : Parcelable.Creator<Order> {
        const val TABLE_NAME = "orders"
        const val COL_ID = "id"
        const val COL_NAME = "name"
        const val COL_ADDRESS = "address"
        const val COL_PHONE = "phone"
        const val COL_READIED = "readied"
        const val COL_TYPE = "type"


        const val CREATE_TABLE =
                "create table $TABLE_NAME ($COL_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "$COL_NAME TEXT NOT NULL, $COL_ADDRESS TEXT NOT NULL, $COL_PHONE TEXT NOT NULL, $COL_READIED INTEGER, $COL_TYPE INTEGER)"

        override fun createFromParcel(parcel: Parcel): Order {
            return Order(parcel)
        }

        override fun newArray(size: Int): Array<Order?> {
            return arrayOfNulls(size)
        }
    }
}
