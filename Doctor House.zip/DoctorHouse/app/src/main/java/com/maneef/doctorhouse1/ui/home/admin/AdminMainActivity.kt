package com.maneef.doctorhouse1.ui.home.admin

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.service.NotificationCenter
import kotlinx.android.synthetic.main.activity_admin_main.*

class AdminMainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_main)
        val i = Intent(this@AdminMainActivity, NotificationCenter::class.java)
        ContextCompat.startForegroundService(this, i)

    }
}