package com.maneef.doctorhouse1.model

data class LabTestForm(val id:Int,val name: String,val age:String,val phone:String,val gender:String,val testsType:String,val testSheet: String,val area: String,val neighbourhood:String,val closetPlace:String,val lat: String,val lang: String,val readied: Int,val type: Int) {

    constructor():this(0,"","","","","","","","","","","",-1,-1)
    constructor(name: String,age:String,phone: String,gender: String,testsType: String,testSheet: String,area: String,neighbourhood: String,closetPlace: String,lat: String,lang: String,readied: Int,type: Int):this(0,name, age, phone, gender, testsType, testSheet, area, neighbourhood, closetPlace,lat,lang,readied,type)

}
