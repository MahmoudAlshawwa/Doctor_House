package com.maneef.doctorhouse1.app

class AppConstants {

    companion object{
        const val TAG = "Rabee"
        const val MEDICAL_FORM = "Medical forms"
        const val MEDICAL_LAB_TESTS = "Medical lab tests"
    }
}