package com.maneef.doctorhouse1.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import com.maneef.doctorhouse1.R
import kotlinx.android.synthetic.main.fragment_order_explain_dialog.view.*


class OrderExplainDialogFragment : DialogFragment() {

    private lateinit var root: View

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_order_explain_dialog, container, false)

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.tv_continue.setOnClickListener {
            when(arguments?.getInt(NAV_DEST)){
                0 ->{
                    dismiss()
                }
                1 ->{
                    dismiss()
                }
            }
        }

        view.tv_cancel_dialog.setOnClickListener {
            dismiss()
        }
        setupView(view.tv_order_brief)
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun setupView(view: View) {
        view.tv_order_brief.text = arguments?.getString(KEY_DATA)
    }

    companion object {
        const val TAG = "OrderExplainDialogFragment"
        private const val KEY_DATA = "KEY_BRIEF"
        private const val NAV_DEST = "nav_destination"

        fun newInstance(personIntel: String,dest: Int): OrderExplainDialogFragment {
            val args = Bundle()
            args.putString(KEY_DATA, personIntel)
            args.putInt(NAV_DEST, dest)
            val fragment = OrderExplainDialogFragment()
            fragment.arguments = args
            return fragment
        }
    }
}