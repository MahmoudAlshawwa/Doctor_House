package com.maneef.doctorhouse1.ui.home.admin

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.adapter.OrdersAdapter
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.model.MedicalForm
import com.maneef.doctorhouse1.model.Order
import com.maneef.doctorhouse1.ui.auth.AuthActivity
import kotlinx.android.synthetic.main.fragment_admin_home.view.*
import kotlinx.android.synthetic.main.fragment_user_home.view.*

class AdminHomeFragment : Fragment() {

    private lateinit var root: View
    private lateinit var auth: FirebaseAuth
    private lateinit var orderList: RecyclerView
    private lateinit var orderListAdapter: OrdersAdapter
    private lateinit var noOrder: TextView
    private lateinit var adminLayout: ConstraintLayout
    private lateinit var database: DatabaseReference
    var orders = ArrayList<Order>()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        auth = Firebase.auth
        database= Firebase.database.reference
        orderListAdapter = OrdersAdapter(requireActivity(), this, orders)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_admin_home, container, false)
        orderList = root.rv_unanswered_orders
        noOrder = root.tv_no_orders_now
        adminLayout = root.cl_admin
        return root

    }

    override fun onResume() {
        super.onResume()
        dataChanged()
        root.btn_sign_out.setOnClickListener {
            signOut()
        }
    }


    private fun dataChanged(){
        database.child(AppConstants.MEDICAL_FORM).addValueEventListener(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (ds in snapshot.children) {
                    val medicalForm = ds.getValue(MedicalForm::class.java)!!
                    var found = false
                    for (i in 0 until orders.size)
                        if (medicalForm.name == orders[i].name)
                            found = true
                    if (!found)
                        orders.add(Order(medicalForm.name, medicalForm.phone, "${medicalForm.area}, ${medicalForm.neighbourhood}, ${medicalForm.closetPlace}", medicalForm.readied, medicalForm.type))
                    Log.d("TAG", "medicalForm $medicalForm and order is $orders")
                }
                try {
                    orderListAdapter = OrdersAdapter(requireActivity(), this@AdminHomeFragment, orders)
                    orderList.adapter = orderListAdapter
                    changeLayOut()
                } catch (e: Exception) {
                }

                Log.d("TAG", "onDataChange order is $orders")
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("Error", "medicalForm ${error.toException()}")
            }
        })

        database.child(AppConstants.MEDICAL_LAB_TESTS).addValueEventListener(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (ds in snapshot.children) {
                    val medicalForm = ds.getValue(MedicalForm::class.java)!!
                    var found = false
                    for (i in 0 until orders.size)
                        if (medicalForm.name == orders[i].name)
                            found = true
                    if (!found)
                        orders.add(Order(medicalForm.name, medicalForm.phone, "${medicalForm.area}, ${medicalForm.neighbourhood}, ${medicalForm.closetPlace}", medicalForm.readied, medicalForm.type))
                    Log.d("TAG", "medicalForm $medicalForm and order is $orders")
                }
                try {
                    orderListAdapter = OrdersAdapter(requireActivity(), this@AdminHomeFragment, orders)
                    orderList.adapter = orderListAdapter
                    changeLayOut()
                } catch (e: Exception) {
                }

                Log.d("TAG", "onDataChange order is $orders")
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("Error", "medicalForm ${error.toException()}")
            }
        })
        changeLayOut()
    }

    fun changeLayOut(){
        if (orderListAdapter.itemCount != 0){
            orderList.visibility = RecyclerView.VISIBLE
            noOrder.visibility = TextView.GONE
        }else{
            orderList.visibility = RecyclerView.GONE
            noOrder.visibility = TextView.VISIBLE
        }

    }

    private fun signOut() {
        auth.signOut()
        updateUI()
    }

    private fun updateUI() {
        val i = Intent(requireContext(), AuthActivity::class.java)
        requireActivity().startActivity(i)
        requireActivity().finish()
    }
}