package com.maneef.doctorhouse1.ui.home.user

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.telephony.PhoneNumberUtils
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.tabs.TabLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.adapter.SectionsPagerAdapter
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.ui.auth.AuthActivity
import kotlinx.android.synthetic.main.activity_user_main.*


class UserMainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_main)

        val sectionsPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager)
        val viewPager: ViewPager = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        tabs.setupWithViewPager(viewPager)
        auth = Firebase.auth
        // Configure Google Sign In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build()
        // [END config_signin]
        googleSignInClient = GoogleSignIn.getClient(this, gso)

    }

    override fun onResume() {
        super.onResume()
        btn_sign_out.setOnClickListener {
            signOut()
        }
        btn_facebook_page.setOnClickListener {
            facebookPage()
        }
        btn_start_whats_app_chat.setOnClickListener {
            openWhatsApp(
                "+962798994508"
            )
        }
    }


    private fun facebookPage() {
        val facebookUrl = "https://www.facebook.com/102348205021939"
        try {
            val versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode
            if (versionCode >= 3002850) {
                val uri = Uri.parse("fb://facewebmodal/f?href=$facebookUrl")
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } else {
                // open the Facebook app using the old method (fb://profile/id or fb://page/id)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/336227679757310")))
            }
        } catch (e: PackageManager.NameNotFoundException) {
            // Facebook is not installed. Open the browser
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(facebookUrl)))
        }
    }
    private fun openWhatsApp(number: String) {
        var number = number
        try {
            number = number.replace(" ", "").replace("+", "")
            val sendIntent = Intent("android.intent.action.MAIN")
            sendIntent.component = ComponentName("com.whatsapp", "com.whatsapp.Conversation")
            sendIntent.putExtra("jid", PhoneNumberUtils.stripSeparators(number) + "@s.whatsapp.net")
            startActivity(sendIntent)
        } catch (e: Exception) {
            Log.e(AppConstants.TAG, "ERROR_OPEN_MESSANGER$e")
        }
    }

    private fun signOut() {
        auth.signOut()
        // Google sign out
        googleSignInClient.signOut().addOnCompleteListener(this) {
            updateUI()
        }
        // Google revoke access
        googleSignInClient.revokeAccess().addOnCompleteListener(this) {
            updateUI()
        }
    }

    private fun updateUI() {
        val i = Intent(this, AuthActivity::class.java)
        startActivity(i)
        finish()
    }
}