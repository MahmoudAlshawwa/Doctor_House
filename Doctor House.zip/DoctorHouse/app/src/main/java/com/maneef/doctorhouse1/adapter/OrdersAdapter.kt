package com.maneef.doctorhouse1.adapter


import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.model.Order
import kotlinx.android.synthetic.main.fragment_home_order_card.view.*

class OrdersAdapter(
    private var activity: Activity,
    val fragment: Fragment,
    var data: ArrayList<Order>
): RecyclerView.Adapter<OrdersAdapter.MyViewHolder>() {

    private var database: DatabaseReference = Firebase.database.reference
    private val storageRef = Firebase.storage.reference
    private val desertRef = storageRef.child("Medical documents/")

    private var orderList = ArrayList<Order>()
    init {
        orderList = data
    }
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val name: TextView = itemView.tv_card_name
        val phone: TextView = itemView.tv_card_phone
        val address: TextView = itemView.tv_card_address
        val cardOpened: TextView = itemView.tv_readied_indicator
        val btnSeeDetails : CardView = itemView.card_see_details
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(activity).inflate(
            R.layout.fragment_home_order_card,
            parent,
            false
        )
        Log.d(AppConstants.TAG, "data $orderList")
        return MyViewHolder(itemView)
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.name.text = orderList[position].name
        holder.phone.text = orderList[position].phone
        holder.address.text = orderList[position].address
        if (orderList[position].readied == 1){
            holder.cardOpened.backgroundTintList = ColorStateList.valueOf(Color.rgb(102, 153, 0))
            holder.cardOpened.text = ("تم\n الإستلام")
        }else{
            holder.cardOpened.backgroundTintList = ColorStateList.valueOf(Color.rgb(204, 0, 0))
            holder.cardOpened.text = ("لم يتم\n الإستلام")
        }
        holder.btnSeeDetails.setOnClickListener {
            when (orderList[position].type){
                0 -> {
                    val bundle = Bundle()
                    bundle.putString("child", orderList[position].name)
                    fragment.findNavController().navigate(
                        R.id.action_adminHomeFragment_to_orderDetailsFragment,
                        bundle
                    )
                }
                1 -> {
                    val bundle = Bundle()
                    bundle.putString("child", orderList[position].name)
                    fragment.findNavController().navigate(
                        R.id.action_adminHomeFragment_to_detailsLaboratoryTestingFragment,
                        bundle
                    )
                }
            }
        }
        holder.btnSeeDetails.setOnLongClickListener {
            val dialogBuilder = AlertDialog.Builder(activity)
            dialogBuilder.setMessage("هل تريد تم تنفيذ هذه الخدمة و تريد إزالتها من قاعدة البيانات؟")
                    .setCancelable(false)
                    .setPositiveButton(R.string.yes) { _, _ ->
                        when (orderList[position].type){
                            0 -> {
                                deleteRequest(AppConstants.MEDICAL_FORM, orderList[position].name!!)
                                removeAt(position)
                            }
                            1 -> {
                                deleteRequest(AppConstants.MEDICAL_LAB_TESTS,orderList[position].name!!,"$orderList[position].name test sheet.png")
                                removeAt(position)
                            }
                        }
                    }
                    .setNegativeButton(R.string.no) { dialog, _ ->
                        dialog.cancel()
                    }
            val alert = dialogBuilder.create()
            alert.setOnShowListener {
                alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
                        .setTextColor(activity.resources.getColor(R.color.colorPrimary))
                alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)
                        .setTextColor(activity.resources.getColor(android.R.color.holo_red_dark))
            }
            alert.show()
            true
        }
    }
    override fun getItemCount(): Int {
        return data.size
    }
    private fun deleteRequest(parent: String, name: String){
        database.child(parent).child(name).removeValue()
                .addOnSuccessListener {
                    Toast.makeText(
                        activity,
                        "تم إزالة الطلب من قاعدة البيانات بنجاح.",
                        Toast.LENGTH_LONG
                    ).show()
                }.addOnFailureListener {
                    Toast.makeText(activity, "حاول مجدداً في وقت لاحق.", Toast.LENGTH_LONG).show()
                }

    }
    private fun deleteRequest(parent: String, name: String,imgNme: String){
        database.child(parent).child(name).removeValue()
            .addOnSuccessListener {
                Toast.makeText(
                    activity,
                    "تم إزالة الطلب من قاعدة البيانات بنجاح.",
                    Toast.LENGTH_LONG
                ).show()
            }.addOnFailureListener {
                Toast.makeText(activity, "حاول مجدداً في وقت لاحق.", Toast.LENGTH_LONG).show()
            }

        desertRef.child(imgNme).delete().addOnSuccessListener {
            // File deleted successfully
        }.addOnFailureListener {
            // Uh-oh, an error occurred!
        }
    }

    fun removeAt(position: Int) {
        orderList.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, orderList.size)
    }
}



