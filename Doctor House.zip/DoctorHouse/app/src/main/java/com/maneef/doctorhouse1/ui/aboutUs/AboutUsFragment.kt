package com.maneef.doctorhouse1.ui.aboutUs

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.telephony.PhoneNumberUtils
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import kotlinx.android.synthetic.main.fragment_about_us.view.*

class AboutUsFragment : Fragment() {

    private lateinit var root: View

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_about_us, container, false)
        root.ll_whats_app_about_us.setOnClickListener {
            openWhatsApp("+962798994508")
        }
        root.ll_face_book_about_us.setOnClickListener {
            facebookPage()
        }
        return root
    }


    private fun facebookPage() {
        val facebookUrl = "https://www.facebook.com/102348205021939"
        try {
            val versionCode = requireActivity().packageManager.getPackageInfo("com.facebook.katana", 0).versionCode
            if (versionCode >= 3002850) {
                val uri = Uri.parse("fb://facewebmodal/f?href=$facebookUrl")
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } else {
                // open the Facebook app using the old method (fb://profile/id or fb://page/id)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/336227679757310")))
            }
        } catch (e: PackageManager.NameNotFoundException) {
            // Facebook is not installed. Open the browser
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(facebookUrl)))
        }
    }
    private fun openWhatsApp(number: String) {
        var number = number
        try {
            number = number.replace(" ", "").replace("+", "")
            val sendIntent = Intent("android.intent.action.MAIN")
            sendIntent.component = ComponentName("com.whatsapp", "com.whatsapp.Conversation")
            sendIntent.putExtra("jid", PhoneNumberUtils.stripSeparators(number) + "@s.whatsapp.net")
            startActivity(sendIntent)
        } catch (e: Exception) {
            Log.e(AppConstants.TAG, "ERROR_OPEN_MESSANGER$e")
        }
    }
}