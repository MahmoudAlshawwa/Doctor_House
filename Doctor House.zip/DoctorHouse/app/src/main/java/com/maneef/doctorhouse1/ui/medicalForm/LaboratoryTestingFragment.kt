package com.maneef.doctorhouse1.ui.medicalForm

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import com.github.ybq.android.spinkit.sprite.Sprite
import com.github.ybq.android.spinkit.style.CubeGrid
import com.google.android.gms.location.LocationServices
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.model.LabTestForm
import com.vansuita.pickimage.bundle.PickSetup
import com.vansuita.pickimage.dialog.PickImageDialog
import kotlinx.android.synthetic.main.fragment_laboratory_testing.view.*
import java.io.ByteArrayOutputStream
import java.util.*


class LaboratoryTestingFragment : Fragment() {

    private lateinit var root: View
    private lateinit var patientLocationLat: String
    private lateinit var patientLocationLang: String
    private lateinit var address: String
    private lateinit var patientName: EditText
    private lateinit var patientAge: EditText
    private lateinit var patientPhone: EditText
    private lateinit var patientGender: RadioGroup
    private lateinit var zone: EditText
    private lateinit var neighbourhood: EditText
    private lateinit var closetPlace: EditText
    private lateinit var btnSubmitForm: TextView
    private lateinit var btnNewRequest: TextView
    private lateinit var btnAddSheetPic: ImageView
    private lateinit var database: DatabaseReference
    private lateinit var pGender: String
    private lateinit var underRevision: TextView
    private lateinit var orderDescription: TextView
    private lateinit var btnOrderNow: TextView
    private lateinit var ivLogoLab: ImageView
    private lateinit var ivHeaderImg: ConstraintLayout
    private lateinit var applicationForm: ScrollView
    private lateinit var progressBar: ProgressBar
    private val storage = Firebase.storage
    private val storageRef = storage.reference
    private val imagesRef = storageRef.child("Medical documents")
    private lateinit var imageURI: Uri
    private lateinit var pName: String
    private lateinit var pAge: String
    private lateinit var pPhone: String
    private lateinit var neededTests: EditText
    private lateinit var pNeededTests: String
    private lateinit var pArea: String
    private lateinit var pNeighbourhood: String
    private lateinit var pClosetPlace: String
    private lateinit var progressBarBackground: View
    private var imageChosen = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_laboratory_testing, container, false)
        database = Firebase.database.reference
        patientName = root.et_lab_patient_name
        patientAge = root.et_lab_patient_age
        patientPhone = root.et_lab_phone_number
        patientGender = root.rg_lab_gender
        zone = root.et_lab_area
        neighbourhood = root.et_lab_neighbourhood
        closetPlace = root.et_lab_closet_place
        btnSubmitForm = root.tv_lab_send_request
        btnNewRequest = root.tv_lab_new_order
        btnAddSheetPic = root.iv_btn_add_sheet
        underRevision = root.tv_lab_under_revision
        applicationForm = root.sv_lab_application_form
        neededTests = root.tv_test1
        progressBar = root.pb_lab
        orderDescription=root.tv_order_lab_description
        btnOrderNow= root.tv_btn_lab_order_now
        ivLogoLab=root.iv_lab_doctor_logo
        ivHeaderImg=root.cl_lab_doctor_logo
        progressBarBackground = root.view_pb_lab_background
        val cubeGrid: Sprite = CubeGrid()
        progressBar.indeterminateDrawable = cubeGrid
        return root
    }
    override fun onResume() {
        super.onResume()
        btnOrderNow.setOnClickListener {
            btnOrderNow.visibility = TextView.GONE
            ivLogoLab.visibility = ImageView.GONE
            orderDescription.visibility = TextView.GONE
            ivHeaderImg.visibility = ConstraintLayout.GONE
            applicationForm.visibility = ScrollView.VISIBLE
        }
        patientGender.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rb_lab_male -> pGender = "ذكر"
                R.id.rb_lab_female -> pGender = "أنثى"
            }
        }
        btnAddSheetPic.setOnClickListener {
            PickImageDialog.build(PickSetup())
                .setOnPickResult {
                    if (it.error == null) {
                        //If you want the Bitmap.
                        imageChosen = true
                        btnAddSheetPic.setImageBitmap(it.bitmap)
                    } else {
                        //Handle possible errors
                        Log.e(AppConstants.TAG, "Error pick Pic"+it.error.message)
                    }
                }
                .setOnPickCancel {
                    imageChosen = false
                }.show(requireActivity().supportFragmentManager)
        }
        btnSubmitForm.setOnClickListener {
            pName = patientName.text.toString()
            pAge = patientAge.text.toString()
            pPhone = patientPhone.text.toString()
            pArea = zone.text.toString()
            pNeighbourhood = neighbourhood.text.toString()
            pClosetPlace = closetPlace.text.toString()
            pNeededTests = neededTests.text.toString()
            if(pName.trim().isEmpty()||pAge.trim().isEmpty()||pPhone.trim().isEmpty()){
                patientName.backgroundTintList = ColorStateList.valueOf(Color.RED)
                patientAge.backgroundTintList = ColorStateList.valueOf(Color.RED)
                patientPhone.backgroundTintList = ColorStateList.valueOf(Color.RED)

                Toast.makeText(requireContext(),"الرجاء تعبئة الخانات المطلوبة",Toast.LENGTH_LONG).show()
            }else{
                permissionDexDialog()

            }
        }
        btnNewRequest.setOnClickListener {
            applicationForm.visibility = ScrollView.VISIBLE
            underRevision.visibility= TextView.GONE
            btnNewRequest.visibility= TextView.GONE
        }
    }
    private fun submitNewMedicalForm(name: String,age: String,phone: String,gender: String,testsType: String,labSheet: String,area: String,neighbourhood: String,closetPlace: String,lat: String,lang:String) {
        val medicalForm = LabTestForm(name,age,phone,gender,testsType,labSheet,area,neighbourhood,closetPlace,lat,lang,0,1)
        database.child(AppConstants.MEDICAL_LAB_TESTS).child(name).setValue(medicalForm)
            .addOnSuccessListener {
                Toast.makeText(requireContext(),"تم إستلام طلبك وجاري التواصل معك",Toast.LENGTH_LONG).show()
                applicationForm.visibility = ScrollView.GONE
                underRevision.visibility = TextView.VISIBLE
                btnNewRequest.visibility= TextView.VISIBLE

            }.addOnFailureListener {
                Log.e(AppConstants.TAG, it.message!!)
                Toast.makeText(requireContext(), "الرجاء المحاولة مجدداً", Toast.LENGTH_LONG).show()
            }
    }
    private fun uploadSheetPic(name: String) {
        showProgressBar()
        val bitmap = (btnAddSheetPic.drawable as BitmapDrawable).bitmap
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data = baos.toByteArray()

        val image = imagesRef.child("$name test sheet.png")
        val uploadTask = image.putBytes(data)

        uploadTask.addOnFailureListener { exception ->
            Log.e(AppConstants.TAG, exception.message.toString())
            // Handle unsuccessful uploads
        }.addOnSuccessListener { uploadTask ->
            image.downloadUrl.addOnSuccessListener { uri ->
                Log.e(AppConstants.TAG, uri.toString())
                imageURI = uri
                submitNewMedicalForm(pName,pAge,pPhone,pGender,pNeededTests,imageURI.toString(),pArea,pNeighbourhood,pClosetPlace,patientLocationLat,patientLocationLang)
                hideProgressBar()
            }.addOnFailureListener { exception ->
                Log.e(AppConstants.TAG, exception.message.toString())
                hideProgressBar()
            }
            Log.e(AppConstants.TAG, "Image uploaded Successfully")
        }
    }
    private fun getLastLocation() {
        val locationServices = LocationServices.getFusedLocationProviderClient(requireActivity())
        locationServices.lastLocation
            .addOnSuccessListener { location ->
                //TODO Dose not change its value
                if (location != null) {
                    patientLocationLat = location.latitude.toString()
                    patientLocationLang = location.longitude.toString()
                    Log.e(AppConstants.TAG, "latitude" + location.latitude.toString())
                    Log.e(AppConstants.TAG, "longitude" + location.longitude.toString())
                    if(imageChosen){
                        uploadSheetPic(patientName.text.toString())

                    }else
                        submitNewMedicalForm(pName,pAge,pPhone,pGender,pNeededTests,"",pArea,pNeighbourhood,pClosetPlace,patientLocationLat,patientLocationLang)

                    val addresses: List<Address>
                    val geocoder = Geocoder(requireActivity(), Locale("ar"))

                    // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                    addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)

                    if (addresses.isEmpty()) {
                        Log.e(AppConstants.TAG, "حاول مجدداً في وقت لاحق.")
                    } else {
                        address = addresses[0]
                            .getAddressLine(0)
                        Log.e(
                            AppConstants.TAG,
                            "geocoder : ${
                                geocoder.getFromLocation(
                                    location.latitude,
                                    location.longitude,
                                    1
                                )
                            }"
                        )
                        Log.e(AppConstants.TAG, "addresses $addresses")

                        //val address: String = addresses[0]
                        // .getAddressLine(0) // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                        if (!addresses[0].adminArea.isNullOrEmpty())
                            zone.hint = addresses[0].adminArea
                        if (!addresses[0].subLocality.isNullOrBlank())
                            neighbourhood.hint = addresses[0].subLocality
                        if (!addresses[0].featureName.isNullOrBlank())
                            closetPlace.hint = addresses[0].featureName
                        Log.e(AppConstants.TAG, "Your Address is: $address")
                    }
                }else{
                    Log.e(AppConstants.TAG, "getLastLocation => location $location")
                    patientLocationLat = "0.0"
                    patientLocationLang = "0.0"
                }
            }.addOnFailureListener { exception ->
                Toast.makeText(
                    requireContext(), "الرجاء قم بتعبئة العنوان يدوياً لوجود خلل ما.",
                    Toast.LENGTH_LONG
                ).show()
                Log.e(AppConstants.TAG, "Error Getting Location :$exception")
            }
    }

    private fun checkGPSEnable() {
        val dialogBuilder = AlertDialog.Builder(requireContext())
        dialogBuilder.setMessage(R.string.gps_check)
            .setCancelable(false)
            .setPositiveButton(R.string.yes) { _, _ ->
                startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }
            .setNegativeButton(R.string.no) { dialog, _ ->
                dialog.cancel()
            }
        val alert = dialogBuilder.create()
        alert.setOnShowListener {
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.colorPrimaryDark))
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(android.R.color.holo_red_dark))
        }
        alert.show()
    }

    private fun permissionDexDialog() {
        Dexter.withContext(requireContext())
            .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(response: PermissionGrantedResponse) {
                    val manager =
                        requireActivity().getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        checkGPSEnable()
                    }
                    locateMyPlace()

                }

                override fun onPermissionRationaleShouldBeShown(
                    p0: PermissionRequest?,
                    p1: PermissionToken?
                ) {
                    p1!!.continuePermissionRequest()
                }

                override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                }
            }).check()
    }

    private fun locateMyPlace() {
        val dialogBuilder = AlertDialog.Builder(requireActivity())
        dialogBuilder.setMessage("هل تريد تحديد موقعك عن تلقائياً عن طريق نظام تحديد المواقع")
            .setCancelable(false)
            .setPositiveButton(R.string.yes) { _, _ ->
                getLastLocation()
            }
            .setNegativeButton(R.string.no) { dialog, _ ->
                dialog.cancel()
            }
        val alert = dialogBuilder.create()
        alert.setOnShowListener {
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.colorPrimary))
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(android.R.color.holo_red_dark))
        }
        alert.show()
    }

    private fun showProgressBar() {
        progressBarBackground.visibility = View.VISIBLE
        progressBar.visibility = ProgressBar.VISIBLE
    }

    private fun hideProgressBar() {
        progressBarBackground.visibility = View.GONE
        progressBar.visibility = ProgressBar.GONE
    }
}