package com.maneef.doctorhouse1.ui.map

import android.content.Context
import androidx.fragment.app.Fragment
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants

class MapsFragment : Fragment() {
    private lateinit var root: View
    private lateinit var myLocation: LatLng
    private lateinit var pLocation: LatLng
    private lateinit var mMap: GoogleMap
    private var pLat = 0.0
    private var pLang = 0.0
    private var isAdmin = -1

    private val callback = OnMapReadyCallback { googleMap ->
        val sp = requireActivity().getSharedPreferences("MyPref", Context.MODE_PRIVATE)
        mMap = googleMap
        googleMap.mapType = GoogleMap.MAP_TYPE_NORMAL
        googleMap.uiSettings.isCompassEnabled = true
        googleMap.uiSettings.isMyLocationButtonEnabled = true
        googleMap.setMyLocationEnabled(true)



        googleMap.setOnMyLocationButtonClickListener {
            getLastLocation()
            true
        }
        isAdmin = sp.getInt("isAdmin", -1)
        if (isAdmin == 1) {
            pLat = requireArguments().getDouble("pLat", 0.0)
            pLang = requireArguments().getDouble("pLang", 0.0)
            if (pLat != 0.0 || pLang!=0.0){
                pLocation = LatLng(pLat, pLang)
                googleMap.addMarker(MarkerOptions().position(pLocation).title("مكان الحالة المرضية"))
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        root = inflater.inflate(R.layout.fragment_maps, container, false)
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }

    private fun getLastLocation() {
        val locationServices = LocationServices.getFusedLocationProviderClient(requireActivity())
        locationServices.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    myLocation = LatLng(location.latitude, location.longitude)
                    if (isAdmin == 1)
                        mMap.addPolyline(PolylineOptions().add(myLocation, pLocation))
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(myLocation, 12f))
                }
            }.addOnFailureListener { exception ->
                Log.e(AppConstants.TAG,"Error ${exception.message}")
            }
    }
}