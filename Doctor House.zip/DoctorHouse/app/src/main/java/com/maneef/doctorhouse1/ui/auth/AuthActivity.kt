package com.maneef.doctorhouse1.ui.auth

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.ybq.android.spinkit.sprite.Sprite
import com.github.ybq.android.spinkit.style.CubeGrid
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.ui.home.admin.AdminMainActivity
import com.maneef.doctorhouse1.ui.home.user.UserMainActivity
import kotlinx.android.synthetic.main.activity_auth.*
import java.util.*


class AuthActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var progressBar: ProgressBar
    private lateinit var contentMain: LinearLayout
    private var isAdmin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        et_email.visibility = EditText.GONE
        et_password.visibility = EditText.GONE
        tv_e_mail_sign_in.visibility = TextView.GONE
        tv_create_new_account.visibility = TextView.GONE
        textView8.visibility = TextView.GONE
        view.visibility = View.GONE

        auth = Firebase.auth

        // Configure Google Sign In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        progressBar = progress_bar
        val cubeGrid: Sprite = CubeGrid()
        progressBar.indeterminateDrawable = cubeGrid
        contentMain = cl_faded
    }

    override fun onResume() {
        super.onResume()

        switch_is_a_doctor.setOnCheckedChangeListener { _, isChecked ->
            if(!isChecked) {
                isAdmin = false
                et_email.visibility = EditText.GONE
                et_password.visibility = EditText.GONE
                tv_e_mail_sign_in.visibility = TextView.GONE
                tv_create_new_account.visibility = TextView.GONE
                textView8.visibility = TextView.GONE
                view.visibility = View.GONE
            } else {
                isAdmin = true
                et_email.visibility = EditText.VISIBLE
                et_password.visibility = EditText.VISIBLE
                tv_e_mail_sign_in.visibility = TextView.VISIBLE
                tv_create_new_account.visibility = TextView.VISIBLE
                textView8.visibility = TextView.VISIBLE
                view.visibility = View.VISIBLE
            }
        }

        tv_sign_in_anonymously.setOnClickListener {
            showProgressBar()
            signInAnonymously()
        }


        iv_btn_google_sign_in.setOnClickListener {
            signIn()
        }

        tv_e_mail_sign_in.setOnClickListener {
            if (et_password.text.toString().trim().isEmpty() || et_email.text.toString().trim()
                    .isEmpty()
            ) {
                Toast.makeText(
                    this, "الرجاءالتأكد من تعبئة الخانات المطلوبة",
                    Toast.LENGTH_SHORT
                ).show()
            } else{
                val sp = getSharedPreferences("MyPref", Context.MODE_PRIVATE)
                val editor = sp.edit()
                if(et_email.text.trim().contains("admin",true)){
                    editor.putInt("isAdmin", 1)
                    val b = editor.commit()
                    if (b)
                        Log.e(AppConstants.TAG, "Admin added Successfully")
                    else
                        Log.e(AppConstants.TAG, "Admin add Failed")
                }else{
                    editor.putInt("isAdmin", 0)
                    val b = editor.commit()
                    if (b)
                        Log.e(AppConstants.TAG, "user added Successfully")
                    else
                        Log.e(AppConstants.TAG, "user add Failed")
                }
                signIn(et_email.text.toString().toLowerCase(Locale.ROOT), et_password.text.toString())
                Log.e(AppConstants.TAG, "signed in")

            }
        }

        tv_e_mail_sign_up.setOnClickListener {
            if (et_password.text.toString().trim().isEmpty() || et_repeat_password.text.toString()
                    .trim().isEmpty() || et_email.text.toString().trim().isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "الرجاءالتأكد من تعبئة الخانات المطلوبة",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                if (et_password.text.toString() != et_repeat_password.text.toString()) {
                    Toast.makeText(
                        this,
                        "الرجاءالتأكد من تطابق كلمة المرور",
                        Toast.LENGTH_SHORT
                    ).show()
                } else{
                    createAccount(et_email.text.toString().toLowerCase(Locale.ROOT), et_password.text.toString())
                }
            }
        }
        tv_create_new_account.setOnClickListener {
            et_repeat_password.visibility = EditText.VISIBLE
            tv_have_an_account.visibility = TextView.VISIBLE
            tv_e_mail_sign_up.visibility = TextView.VISIBLE
            textView8.text = ("لديك حساب ؟!")
            tv_create_new_account.visibility = TextView.GONE
            tv_e_mail_sign_in.visibility = TextView.GONE
        }

        tv_have_an_account.setOnClickListener {
            et_repeat_password.visibility = EditText.GONE
            tv_have_an_account.visibility = TextView.GONE
            tv_e_mail_sign_up.visibility = TextView.GONE
            textView8.text = resources.getString(R.string.do_not_have_account_label)
            tv_create_new_account.visibility = TextView.VISIBLE
            tv_e_mail_sign_in.visibility = TextView.VISIBLE

        }
    }
    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        if(auth.currentUser != null)
            if (auth.currentUser!!.email?.contains("admin", true) == true)
                isAdmin = true
        updateUI(currentUser)
    }
    private fun signInAnonymously(){
        val sp = getSharedPreferences("MyPref", Context.MODE_PRIVATE)
        val editor = sp.edit()
        editor.putInt("isAdmin", 0)
        val b = editor.commit()
        if (b)
            Log.e(AppConstants.TAG, "user added Successfully Anonymously")
        else
            Log.e(AppConstants.TAG, "user add Failed Anonymously")
        auth.signInAnonymously()
                .addOnCompleteListener(this) { task ->
                    hideProgressBar()
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        Log.d(AppConstants.TAG, "signInAnonymously:success")
                        val user = auth.currentUser
                        updateUI(user)
                    } else {
                        // If sign in fails, display a message to the user.
                        Log.w(AppConstants.TAG, "signInAnonymously:failure", task.exception)
                        Toast.makeText(baseContext, "Authentication failed.",
                                Toast.LENGTH_SHORT).show()
                        updateUI(null)
                    }
                }
    }
    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                // Google Sign In was successful, authenticate with Firebase
                val account = task.getResult(ApiException::class.java)!!
                Log.d(AppConstants.TAG, "firebaseAuthWithGoogle:" + account.id)
                firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: ApiException) {
                // Google Sign In failed, update UI appropriately
                Log.w(AppConstants.TAG, "Google sign in failed", e)
                // ...
            }
        }
    }
    private fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(AppConstants.TAG, "signInWithCredential:success")
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(AppConstants.TAG, "signInWithCredential:failure", task.exception)
                    // ...
                    Toast.makeText(this, "Authentication Failed.", Toast.LENGTH_SHORT).show()
                    updateUI(null)
                }
            }
    }
    private fun updateUI(user: FirebaseUser?) {
        if (user != null) {
            if(auth.currentUser != null){
                isAdmin = auth.currentUser!!.email?.contains("admin", true) == true
            }
            if (isAdmin){
                val i = Intent(this, AdminMainActivity::class.java)
                startActivity(i)
                finish()
            }else{
                val i = Intent(this, UserMainActivity::class.java)
                startActivity(i)
                finish()
            }

        }
    }
    //==================================E-mail Sign in================================================
    private fun createAccount(email: String, password: String) {
        Log.d(AppConstants.TAG, "createAccount:$email")
        if (!validateForm()) {
            return
        }
        showProgressBar()
        // [START create_user_with_email]
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(AppConstants.TAG, "createUserWithEmail:success")
                    Toast.makeText(baseContext, "الرجاء تفقد البريد الإلكتروني لتفعيل الحساب.", Toast.LENGTH_SHORT).show()
                    val user = auth.currentUser
                    sendEmailVerification()
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(AppConstants.TAG, "createUserWithEmail:failure", task.exception)
                    Toast.makeText(baseContext, "الرجاء المحاولة لاحقاً.", Toast.LENGTH_SHORT).show()
                    updateUI(null)
                }

                // [START_EXCLUDE]
                hideProgressBar()
                // [END_EXCLUDE]
            }
        // [END create_user_with_email]
    }
    private fun signIn(email: String, password: String) {
        Log.d(AppConstants.TAG, "signIn:$email")
        if (!validateForm()) {
            return
        }
        showProgressBar()
        // [START sign_in_with_email]
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(AppConstants.TAG, "signInWithEmail:success")
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(AppConstants.TAG, "signInWithEmail:failure", task.exception)
                    Toast.makeText(this, "Authentication failed.", Toast.LENGTH_SHORT).show()
                    updateUI(null)
                }

                // [START_EXCLUDE]
                if (!task.isSuccessful) {
                    Toast.makeText(this, "Authentication failed.", Toast.LENGTH_SHORT).show()
                }
                hideProgressBar()
                // [END_EXCLUDE]
            }
        // [END sign_in_with_email]
    }
    private fun sendEmailVerification() {
        // Send verification email
        // [START send_email_verification]
        val user = auth.currentUser!!
        user.sendEmailVerification()
                .addOnCompleteListener(this) { task ->
                    // [START_EXCLUDE]
                    if (task.isSuccessful) {
                        Toast.makeText(baseContext,
                                "Verification email sent to ${user.email} ",
                                Toast.LENGTH_SHORT).show()
                    } else {
                        Log.e(AppConstants.TAG, "sendEmailVerification", task.exception)
                        Toast.makeText(baseContext,
                                "Failed to send verification email.",
                                Toast.LENGTH_SHORT).show()
                    }
                    // [END_EXCLUDE]
                }
        // [END send_email_verification]
    }
    private fun reload() {
        auth.currentUser!!.reload().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                updateUI(auth.currentUser)
                Toast.makeText(this, "Reload successful!", Toast.LENGTH_SHORT).show()
            } else {
                Log.e(AppConstants.TAG, "reload", task.exception)
                Toast.makeText(this, "Failed to reload user.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun validateForm(): Boolean {
        var valid = true
        if (et_email.text.isEmpty()) {
            et_email.error = "Required."
            valid = false
        } else {
            et_email.error = null
        }

        if (et_password.text.isEmpty()) {
            et_password.error = "Required."
            valid = false
        } else {
            et_password.error = null
        }

        return valid
    }
    private fun showProgressBar() {
        progressBar.visibility = ProgressBar.VISIBLE
    }

    private fun hideProgressBar() {
        progressBar.visibility = ProgressBar.GONE
    }
    companion object {
        private const val RC_SIGN_IN = 9001
    }
}