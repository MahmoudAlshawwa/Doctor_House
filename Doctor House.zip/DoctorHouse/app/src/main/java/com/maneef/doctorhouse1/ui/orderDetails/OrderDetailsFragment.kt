package com.maneef.doctorhouse1.ui.orderDetails

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.github.ybq.android.spinkit.sprite.Sprite
import com.github.ybq.android.spinkit.style.CubeGrid
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.model.MedicalForm
import kotlinx.android.synthetic.main.fragment_order_details.view.*


class OrderDetailsFragment : Fragment() {
    private lateinit var root: View
    private lateinit var database: DatabaseReference
    private lateinit var myLocationDetails: LatLng
    private lateinit var patientNameDetails: TextView
    private lateinit var patientAgeDetails: TextView
    private lateinit var patientPhoneDetails: TextView
    private lateinit var patientGenderDetails: TextView
    private lateinit var askedOrders : TextView
    private lateinit var medicalHistoryDetails: TextView
    private lateinit var medicineAllergicDetails: TextView
    private lateinit var additionalInfoDetails: TextView
    private lateinit var addressDetails: TextView
    private lateinit var neighbourhoodDetails: TextView
    private lateinit var closetPlaceDetails: TextView
    private lateinit var btnGoToMapDetails: TextView
    private lateinit var btnSubmitFormDetails: TextView
    private lateinit var btnCancelRequestDetails: TextView
    private lateinit var databaseDetails: DatabaseReference
    private lateinit var pGenderDetails: String
    private lateinit var child: String
    private lateinit var progressBar: ProgressBar
    private lateinit var pLat: String
    private lateinit var pLang: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_order_details, container, false)
        database = Firebase.database.reference
        child = requireArguments().getString("child")!!
        getSingleChild(child)
        patientNameDetails = root.tv_details_patient_name
        patientAgeDetails = root.tv_details_patient_age
        patientPhoneDetails = root.tv_details_phone_number
        patientGenderDetails = root.tv_details_gender
        askedOrders = root.tv_asked_orders
        medicalHistoryDetails = root.tv_details_medical_history
        medicineAllergicDetails = root.tv_details_medicine_allergic
        additionalInfoDetails = root.et_additional_info
        addressDetails = root.tv_details_address
        btnSubmitFormDetails = root.tv_accept_request
        btnGoToMapDetails = root.tv_details_go_to_map
        progressBar = root.pb_details_fragment
        val cubeGrid: Sprite = CubeGrid()
        progressBar.indeterminateDrawable = cubeGrid
        return root
    }

    override fun onResume() {
        super.onResume()
        btnSubmitFormDetails.setOnClickListener {
            updateFormStatus(child)
            findNavController().navigate(R.id.action_orderDetailsFragment_to_adminHomeFragment)
        }
        btnGoToMapDetails.setOnClickListener {
            showProgressBar()
            Dexter.withContext(requireContext())
                    .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    .withListener(object : PermissionListener {
                        override fun onPermissionGranted(response: PermissionGrantedResponse) {
                            val manager =
                                    requireActivity().getSystemService(Context.LOCATION_SERVICE) as LocationManager
                            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                                hideProgressBar()
                                checkGPSEnable()
                            } else {
                                hideProgressBar()
                                val bndl = Bundle()
                                bndl.putDouble("pLat",pLat.toDouble())
                                bndl.putDouble("pLang",pLang.toDouble())
                                findNavController().navigate(R.id.action_orderDetailsFragment_to_mapsFragment,bndl)
                            }
                        }

                        override fun onPermissionRationaleShouldBeShown(
                                p0: PermissionRequest?,
                                p1: PermissionToken?
                        ) {
                            hideProgressBar()
                            p1!!.continuePermissionRequest()
                        }

                        override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                            hideProgressBar()
                        }
                    }).check()
        }
    }

    private fun getSingleChild(child: String) {
        database.child(AppConstants.MEDICAL_FORM).child(child)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val medicalForm = snapshot.getValue(MedicalForm::class.java)
                        if (medicalForm != null) {
                            patientNameDetails.text = ("الإسم:  ${medicalForm.name}")
                            patientAgeDetails.text = ("العمر:  ${medicalForm.age}")
                            patientPhoneDetails.text = ("رقم الجوال: ${medicalForm.phone}")
                            patientGenderDetails.text = (medicalForm.gender)
                            val askedO = medicalForm.orderTypesAsked[0] + medicalForm.orderTypesAsked[1] + medicalForm.orderTypesAsked[2] + medicalForm.orderTypesAsked[3] + medicalForm.orderTypesAsked[4] + medicalForm.orderTypesAsked[5] + medicalForm.orderTypesAsked[6]
                            askedOrders.text =  askedO
                            medicalHistoryDetails.text = (medicalForm.medicalHistory)
                            medicineAllergicDetails.text = ("حساسية من الأدوية:  ${medicalForm.medicineAllergic}")
                            additionalInfoDetails.text = medicalForm.additionalInfo
                            val address = "${medicalForm.area} ${medicalForm.neighbourhood} ${medicalForm.closetPlace}"
                            addressDetails.text = address
                            pLat = medicalForm.lat
                            pLang = medicalForm.lang
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.d("Error", "medicalForm ${error.toException()}")

                    }

                })

    }

    private fun updateFormStatus(child: String) {
        database.child(AppConstants.MEDICAL_FORM).child(child).child("readied").setValue(1)
                .addOnSuccessListener {
                    Toast.makeText(requireContext(),"تم الإستلام بنجاح", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(),"هناك خلل ما، حاول مجدداً في وقت آخر.", Toast.LENGTH_LONG).show()
                }
    }

    private fun checkGPSEnable() {
        val dialogBuilder = AlertDialog.Builder(requireContext())
        dialogBuilder.setMessage(R.string.gps_check)
                .setCancelable(false)
                .setPositiveButton(R.string.yes) { _, _ ->
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton(R.string.no) { dialog, _ ->
                    dialog.cancel()
                }
        val alert = dialogBuilder.create()
        alert.setOnShowListener {
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
                    .setTextColor(resources.getColor(R.color.colorPrimaryDark))
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)
                    .setTextColor(resources.getColor(android.R.color.holo_red_dark))
        }
        alert.show()
    }

    private fun showProgressBar() {
        progressBar.visibility = ProgressBar.VISIBLE
    }

    private fun hideProgressBar() {
        progressBar.visibility = ProgressBar.GONE
    }
}