package com.maneef.doctorhouse1.ui.medicalForm

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import com.github.ybq.android.spinkit.sprite.Sprite
import com.github.ybq.android.spinkit.style.CubeGrid
import com.google.android.gms.location.LocationServices
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import com.maneef.doctorhouse1.R
import com.maneef.doctorhouse1.app.AppConstants
import com.maneef.doctorhouse1.model.MedicalForm
import kotlinx.android.synthetic.main.fragment_medical_form.view.*
import java.util.*
import kotlin.collections.ArrayList


class MedicalFormFragment : Fragment() {

    private lateinit var root: View
    private lateinit var patientLocationLat: String
    private lateinit var patientLocationLang: String
    private lateinit var address: String
    private lateinit var patientName: EditText
    private lateinit var patientAge: EditText
    private lateinit var patientPhone: EditText
    private lateinit var patientGender: RadioGroup
    private lateinit var medicalHistory: EditText
    private lateinit var medicineAllergic: EditText
    private lateinit var additionalInfo: EditText
    private lateinit var zone: EditText
    private lateinit var neighbourhood: EditText
    private lateinit var closetPlace: EditText
    private lateinit var btnSubmitForm: TextView
    private lateinit var btnNewRequest: TextView
    private lateinit var database: DatabaseReference
    private lateinit var pGender: String
    private lateinit var underRevision: TextView
    private lateinit var orderDescription: TextView
    private lateinit var btnOrderNow: TextView
    private lateinit var ivLogoLab: ImageView
    private lateinit var ivHeaderImg: ConstraintLayout
    private lateinit var applicationForm: ScrollView
    private lateinit var choice1: CheckBox
    private lateinit var choice2: CheckBox
    private lateinit var choice3: CheckBox
    private lateinit var choice4: CheckBox
    private lateinit var choice5: CheckBox
    private lateinit var choice6: CheckBox
    private lateinit var somethingElse: EditText
    private lateinit var orderType: ArrayList<String>
    private lateinit var pName : String
    private lateinit var pAge : String
    private lateinit var pPhone : String
    private lateinit var pHistory : String
    private lateinit var pAllergic : String
    private lateinit var eInfo : String
    private lateinit var pArea: String
    private lateinit var pNeighbourhood : String
    private lateinit var pClosetPlace : String
    private lateinit var progressBar: ProgressBar
    private lateinit var progressBarBackground: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_medical_form, container, false)
        database = Firebase.database.reference
        patientName = root.et_patient_name
        patientAge = root.et_patient_age
        patientPhone = root.et_phone_number
        patientGender = root.rg_gender
        medicalHistory = root.et_medical_history
        medicineAllergic = root.et_medicine_allergic
        additionalInfo = root.et_additional_info
        zone = root.et_area
        neighbourhood = root.et_neighbourhood
        closetPlace = root.et_closet_place
        btnSubmitForm = root.tv_send_request
        btnNewRequest = root.tv_new_order
        underRevision = root.tv_under_revision
        applicationForm = root.sv_application_form
        choice1 = root.cb_choice1
        choice2 = root.cb_choice2
        choice3 = root.cb_choice3
        choice4 = root.cb_choice4
        choice5 = root.cb_choice5
        choice6 = root.cb_choice6
        somethingElse = root.et_something_else
        orderType = arrayListOf("","","","","","","")
        progressBar = root.pb_medical_form
        orderDescription=root.tv_order_description
        btnOrderNow= root.tv_btn_order_now
        ivLogoLab=root.iv_doctor_logo
        ivHeaderImg=root.cl_doctor_logo
        val cubeGrid: Sprite = CubeGrid()
        progressBar.indeterminateDrawable = cubeGrid
        progressBarBackground = root.view_pb_background
        return root
    }


    override fun onResume() {
        super.onResume()
        btnOrderNow.setOnClickListener {
            btnOrderNow.visibility = TextView.GONE
            ivLogoLab.visibility = ImageView.GONE
            orderDescription.visibility = TextView.GONE
            ivHeaderImg.visibility = ConstraintLayout.GONE
            applicationForm.visibility = ScrollView.VISIBLE
        }
        patientGender.setOnCheckedChangeListener { _, checkedId ->
            when(checkedId){
                R.id.rb_male -> pGender = "ذكر"
                R.id.rb_female -> pGender = "أنثى"
            }
        }
        choice1.setOnClickListener {
            if (choice1.isChecked)
                orderType[0] = "${choice1.text}\n"
            else
                orderType[0] = ""
        }
        choice2.setOnClickListener {
            if (choice2.isChecked)
                orderType[1] = "${choice2.text}\n"
            else
                orderType[1] = ""

        }
        choice3.setOnClickListener {
            if (choice3.isChecked)
                orderType[2]="${choice3.text}\n"
            else
                orderType[2] = ""

        }
        choice4.setOnClickListener {
            if (choice4.isChecked)
                orderType[3]="${choice4.text}\n"
            else
                orderType[3] = ""

        }
        choice5.setOnClickListener {
            if (choice5.isChecked)
                orderType[4]= "${choice5.text}\n"
            else
                orderType[4] = ""

        }
        choice6.setOnClickListener {
            if (choice6.isChecked)
                orderType[5]="${choice6.text}\n"
            else
                orderType[5] = ""

        }
        btnSubmitForm.setOnClickListener {
            showProgressBar()
            pName = patientName.text.toString()
            pAge = patientAge.text.toString()
            pPhone = patientPhone.text.toString()
            pHistory = medicalHistory.text.toString()
            pAllergic = medicineAllergic.text.toString()
            eInfo = additionalInfo.text.toString()
            pArea = zone.text.toString()
            pNeighbourhood = neighbourhood.text.toString()
            pClosetPlace = closetPlace.text.toString()
            if (somethingElse.text.trim().isEmpty()){
                orderType[6] = ""
            }else{
                orderType[6]="${somethingElse.text}\n"
            }
            if(pName.trim().isEmpty()||pAge.trim().isEmpty()||pPhone.trim().isEmpty()||pHistory.trim().isEmpty()||pAllergic.trim().isEmpty()){
                if (pName.trim().isEmpty())
                    patientName.backgroundTintList = ColorStateList.valueOf(Color.RED)
                if (pAge.trim().isEmpty())
                    patientAge.backgroundTintList = ColorStateList.valueOf(Color.RED)
                if (pPhone.trim().isEmpty())
                    patientPhone.backgroundTintList = ColorStateList.valueOf(Color.RED)
                if (pHistory.trim().isEmpty())
                    medicalHistory.backgroundTintList = ColorStateList.valueOf(Color.RED)
                if (pAllergic.trim().isEmpty())
                    medicineAllergic.backgroundTintList = ColorStateList.valueOf(Color.RED)
                Toast.makeText(requireContext(),"الرجاء تعبئة الخانات المطلوبة",Toast.LENGTH_LONG).show()
            }else{
                permissionDexDialog()
            }
        }

        btnNewRequest.setOnClickListener {
            applicationForm.visibility = ScrollView.VISIBLE
            underRevision.visibility= TextView.GONE
            btnNewRequest.visibility= TextView.GONE
        }
    }

    private fun submitNewMedicalForm(name: String, age: String, phone: String, gender: String, mHistory: String, mAllergic: String, extraInfo: String, area: String, neighbourhood: String, closetPlace: String,lat: String,lang: String,orderList: ArrayList<String>) {
        val medicalForm = MedicalForm(name, age, phone, gender, mHistory, mAllergic, extraInfo, area, neighbourhood, closetPlace,lat,lang,orderList,0,0)
        database.child(AppConstants.MEDICAL_FORM).child(name).setValue(medicalForm).addOnSuccessListener {
            Toast.makeText(requireContext(), "تم إستلام طلبك وجاري التواصل معك", Toast.LENGTH_LONG).show()
            hideProgressBar()
            applicationForm.visibility = ScrollView.GONE
            underRevision.visibility= TextView.VISIBLE
            btnNewRequest.visibility= TextView.VISIBLE
        }.addOnFailureListener {
            hideProgressBar()
            Log.e(AppConstants.TAG, it.message!!)
            Toast.makeText(requireContext(), "الرجاء المحاولة مجدداً", Toast.LENGTH_LONG).show()
        }
    }

    private fun getLastLocation() {
        Log.e(AppConstants.TAG, "getLastLocation")
        val locationServices = LocationServices.getFusedLocationProviderClient(requireActivity())
        locationServices.lastLocation
            .addOnSuccessListener { location ->
                //TODO Dose not change its value
                if (location != null) {
                    patientLocationLat = location.latitude.toString()
                    patientLocationLang = location.longitude.toString()
                    Log.e(AppConstants.TAG, "latitude" + location.latitude.toString())
                    Log.e(AppConstants.TAG, "longitude" + location.longitude.toString())
                    submitNewMedicalForm(pName, pAge, pPhone, pGender, pHistory, pAllergic, eInfo, pArea, pNeighbourhood, pClosetPlace,patientLocationLat,patientLocationLang,orderType)

                    val addresses: List<Address>
                    val geocoder = Geocoder(requireActivity(), Locale("ar"))

                    // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                    addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)

                    if (addresses.isEmpty()) {
                        Log.e(AppConstants.TAG, "حاول مجدداً في وقت لاحق.")
                    } else {
                        address = addresses[0]
                            .getAddressLine(0)
                        Log.e(AppConstants.TAG,"geocoder : ${geocoder.getFromLocation(location.latitude,location.longitude,1)}")
                        Log.e(AppConstants.TAG, "addresses $addresses")

                        //val address: String = addresses[0]
                        // .getAddressLine(0) // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                        if (!addresses[0].adminArea.isNullOrEmpty())
                            zone.hint = addresses[0].adminArea
                        if (!addresses[0].subLocality.isNullOrBlank())
                            neighbourhood.hint = addresses[0].subLocality
                        if (!addresses[0].featureName.isNullOrBlank())
                            closetPlace.hint = addresses[0].featureName
                        Log.e(AppConstants.TAG, "Your Address is: $address")
                    }
                }else{
                    Log.e(AppConstants.TAG, "getLastLocation => location $location")
                    submitNewMedicalForm(pName, pAge, pPhone, pGender, pHistory, pAllergic, eInfo, pArea, pNeighbourhood, pClosetPlace,"0.0","0.0",orderType)
                }
            }.addOnFailureListener { exception ->
                Toast.makeText(requireContext(),"الرجاء قم بتعبئة العنوان يدوياً لوجود خلل ما.",Toast.LENGTH_LONG).show()
                Log.e(AppConstants.TAG, "Error Getting Location :$exception")
            }
    }

    private fun checkGPSEnable() {
        val dialogBuilder = AlertDialog.Builder(requireContext())
        dialogBuilder.setMessage(R.string.gps_check)
            .setCancelable(false)
            .setPositiveButton(R.string.yes) { _, _ ->
                startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                Log.e(AppConstants.TAG, "checkGPSEnable")

            }
            .setNegativeButton(R.string.no) { dialog, _ ->
                dialog.cancel()
            }
        val alert = dialogBuilder.create()
        alert.setOnShowListener {
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.colorPrimaryDark))
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(android.R.color.holo_red_dark))
        }
        alert.show()
    }

    private fun permissionDexDialog(){
        Dexter.withContext(requireContext())
            .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(response: PermissionGrantedResponse) {
                    val manager =
                        requireActivity().getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        checkGPSEnable()
                        Log.e(AppConstants.TAG, "permissionDexDialog =>  checkGPSEnable")

                    }
                    locateMyPlace()
                    Log.e(AppConstants.TAG, "permissionDexDialog =>  locateMyPlace")

                }
                override fun onPermissionRationaleShouldBeShown(
                    p0: PermissionRequest?,
                    p1: PermissionToken?
                ) {
                    p1!!.continuePermissionRequest()
                }

                override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                }
            }).check()
    }

    private fun locateMyPlace(){
        val dialogBuilder = AlertDialog.Builder(requireActivity())
        dialogBuilder.setMessage("هل تريد تحديد موقعك عن تلقائياً عن طريق نظام تحديد المواقع")
            .setCancelable(false)
            .setPositiveButton(R.string.yes) { _, _ ->
                Log.e(AppConstants.TAG, "locateMyPlace => getLastLocation")
                getLastLocation()

            }
            .setNegativeButton(R.string.no) { dialog, _ ->
                dialog.cancel()
            }
        val alert = dialogBuilder.create()
        alert.setOnShowListener {
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.colorPrimary))
            alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(android.R.color.holo_red_dark))
        }
        alert.show()
    }



    private fun showProgressBar() {
        progressBarBackground.visibility = View.VISIBLE
        progressBar.visibility = ProgressBar.VISIBLE
    }

    private fun hideProgressBar() {
        progressBarBackground.visibility = View.GONE
        progressBar.visibility = ProgressBar.GONE
    }
}