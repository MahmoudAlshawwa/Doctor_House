package com.maneef.doctorhouse1.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.maneef.doctorhouse1.model.Order

class AppDBHelper(context: Context) :
        SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {


    private var db: SQLiteDatabase
    init {
        db = writableDatabase
    }

    override fun onCreate(p0: SQLiteDatabase?) {
        p0!!.execSQL(Order.CREATE_TABLE)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        p0!!.execSQL("DROP TABLE IF EXISTS ${Order.TABLE_NAME}")
        onCreate(p0)
    }
    //==================================================================

    fun addOrder(name: String, address: String,phone: String): Boolean {
        val cv = ContentValues()
        cv.put(Order.COL_NAME, name)
        cv.put(Order.COL_ADDRESS, address)
        cv.put(Order.COL_PHONE, phone)
        return db.insert(Order.TABLE_NAME, null, cv) > 0
    }

    fun getAllOrders(): ArrayList<Order> {
        val orders = ArrayList<Order>()
        val c =
                db.rawQuery("select * from ${Order.TABLE_NAME} order by ${Order.COL_ID} DESC", null)
        c.moveToFirst()
        while (!c.isAfterLast) {
            val odr = Order(c.getString(0), c.getString(1), c.getString(2),c.getInt(4),c.getInt(5))
            orders.add(odr)
            c.moveToNext()
        }
        c.close()
        return orders
    }

    fun deleteOrder(id:Int) : Boolean{
        return db.delete(Order.TABLE_NAME,"id = $id",null)>0
    }


    companion object {
        const val DATABASE_NAME = "AppDB"
        const val DATABASE_VERSION = 1
    }
}